#!/bin/bash

echo "Deleting *.uds *.bin *.npy"
rm *.uds *.bin *.npy
