#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#define DRIVER_NAME "/proc/stat" // driver name
//#define DEBUG_ON // debug messages // display debug outputs
#define OPEN_INFUNC // driver opens EVERY iteration of the code... bad
//#define OPEN_OUTFUNC // driver opens once throughout the code

/* All the values reading from /proc/stat for the calculation */
struct statValues{
	float user;
	float nice;
	float sys;
	float idle;
	float prev_idle;
	float iowait;
	float irq;
	float softirq;

	float ttl;
	float prev_ttl;
	float non_idle;
	float idleNew;
};

int fp;

int openDriver()
{
	#ifdef DEBUG_ON // debug messages
	printf("\nOpening Driver %s\n",DRIVER_NAME);
	#endif
	int status;
	/* Open File */
	fp = open(DRIVER_NAME, O_RDONLY);
	if (fp == 0)
	{
		printf("Error opening %s, %s\n",DRIVER_NAME,strerror(errno));
		return -1;
	}

	return 0;
}

int closeDriver()
{
	#ifdef DEBUG_ON // debug messages
	printf("\nClosing Driver %s\n",DRIVER_NAME);
	#endif
	int status;
	status = close(fp);
	if (status != 0)
	{
		printf("Error closing %s, %s\n",DRIVER_NAME, strerror(errno));
		return -1;
	}
	return 0;
}

/*
Reads /proc/stat and parses data and calculates total
cat /proc/stat: CPU user nice system idle iowait irq softirq

user: normal processes executing in user mode
nice: niced processes executing in user mode
system: processes executing in kernel mode
idle: twiddling thumbs
iowait: waiting for I/O to complete
irq: servicing interrupts
softirq: servicing softirqs
*/
int readProcStat()
{
	#ifdef DEBUG_ON // debug messages
	printf("Read called\n");
	#endif

	int i;
	struct statValues stat;

	#ifdef DEBUG_ON // debug messages
	printf("\nOutput from reading /proc/stat\n");
	printf("Column meanings:\nCPU user nice system idle iowait irq softirq\n");
	#endif

	for(i = 0; i<200; i++)
	{
		/* Open driver every iteration */
		#ifdef OPEN_INFUNC
		openDriver();
		#endif

		char *p;
		char buff[2000];
		size_t status;
		const char *delim = " ";

		/* Read /proc/stat */
		status = read(fp,buff,sizeof(buff));
		if (status < 0)
		{
			printf("Error reading from %s, %s\n",DRIVER_NAME,strerror(errno));
			return -1;
		}

		/* returns CPU term and tosses it */
		p = strtok(buff,delim);
		if (NULL == p)
		{
			printf("Error parsing input for cpu resources\n");
			return -1;
		}

		/* returns user status */
		p = strtok(NULL,delim);
		if (NULL == p)
		{
			printf("Error parsing input for user resources\n");
			return -1;
		}
		stat.user = atof(p);
		#ifdef DEBUG_ON // debug messages
		printf("user: %f\n",stat.user);
		#endif

		/* returns nice status */
		p = strtok(NULL,delim);
		if (NULL == p)
		{
			printf("Error parsing input for nice resources\n");
			return -1;
		}
		stat.nice = atof(p);
		#ifdef DEBUG_ON // debug messages
		printf("nice: %f\n",stat.nice);
		#endif

		/* returns system status */
		p = strtok(NULL,delim);
		if (NULL == p)
		{
			printf("Error parsing input for system resources\n");
			return -1;
		}
		stat.sys = atof(p);
		#ifdef DEBUG_ON // debug messages
		printf("sys: %f\n",stat.sys);
		#endif

		/* returns idle status */
		p = strtok(NULL,delim);
		if (NULL == p)
		{
			printf("Error parsing input for idle resources\n");
			return -1;
		}
		stat.idle = atof(p);
		#ifdef DEBUG_ON // debug messages
		printf("idle: %f\n",stat.idle);
		#endif

		/* returns iowait status */
		p = strtok(NULL,delim);
		if (NULL == p)
		{
			printf("Error parsing input for iowait resources\n");
			return -1;
		}
		stat.iowait = atof(p);
		#ifdef DEBUG_ON // debug messages
		printf("iowait: %f\n",stat.iowait);
		#endif

		/* returns irq status */
		p = strtok(NULL,delim);
		if (NULL == p)
		{
			printf("Error parsing input for irq resources\n");
			return -1;
		}
		stat.irq = atof(p);
		#ifdef DEBUG_ON // debug messages
		printf("irq: %f\n",stat.irq);
		#endif

		/* returns softirq status */
		p = strtok(NULL,delim);
		if (NULL == p)
		{
			printf("Error parsing input for softirq resources\n");
			return -1;
		}
		stat.softirq = atof(p);
		#ifdef DEBUG_ON // debug messages
		printf("softirq: %f\n",stat.softirq);
		#endif

		/*
		* Calculate actual usage
		*/
		stat.idleNew = stat.idle + stat.iowait;
		stat.non_idle = stat.user + stat.nice + stat.sys + stat.irq + stat.softirq;
		stat.ttl = stat.idleNew + stat.non_idle;

		/* First iteration used for base-line data -- no output */
		if(i != 0)
		{
			float cpu = ((stat.ttl - stat.prev_ttl)-(stat.idleNew - stat.prev_idle))/(stat.ttl - stat.prev_ttl)*100;
			printf(">>>CPU Usage : %.2f %%\n", cpu);
		}

		stat.prev_idle = stat.idleNew;
		stat.prev_ttl = stat.ttl;

		/* Stat updates SLOW, must wait AT LEAST one second between reads */
		sleep(1);

		/* Close Driver every iteration :( */
		#ifdef OPEN_INFUNC
		closeDriver();
		#endif
	}
	return 0;
}

int main()
{
	int status;

	#ifdef DEBUG_ON // debug messages
	printf("Reading proc stat...\n");
	#endif

	/* Leave openDriver once for program */
	#ifdef OPEN_OUTFUNC
	openDriver();
	#endif

	status = readProcStat();

	/* Closes driver in event of failure from inside the loop */
	#ifdef OPEN_INFUNC
	if(status == -1)
		closeDriver();
	#endif

	/* Close Driver once for program */
	#ifdef OPEN_OUTFUNC
	closeDriver();
	#endif

	return 0;
}
